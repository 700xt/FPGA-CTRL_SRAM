library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity SDRAM_ctrl is
    Port ( 
        usr_data_in  : in  STD_LOGIC_VECTOR (31 downto 0);
        usr_data_out : out STD_LOGIC_VECTOR (31 downto 0);
        RW           : in  STD_LOGIC;  -- 0 = write, 1 = read
        ctrl_RW      : in  STD_LOGIC;  -- commande active
        clk          : in  STD_LOGIC;
        usr_addr     : in  STD_LOGIC_VECTOR (18 downto 0);
        DQ           : inout STD_LOGIC_VECTOR (35 downto 0);
        addr         : out STD_LOGIC_VECTOR (18 downto 0);
        Trig         : out STD_LOGIC;
        reset        : in STD_LOGIC;

        -- ?? Signaux de commande vers la SRAM
        nCKE        : out STD_LOGIC;                                   -- Clock Enable
        --nRW         : out STD_LOGIC;                                   -- Read/Write control
        Lbo_n       : out STD_LOGIC;                                   -- Burst Mode
        Cke_n       : out STD_LOGIC;                                   -- Cke#
        Ld_n        : out STD_LOGIC;                                   -- Adv/Ld#
        Bwa_n       : out STD_LOGIC;                                   -- Bwa#
        Bwb_n       : out STD_LOGIC;                                   -- BWb#
        Bwc_n       : out STD_LOGIC;                                   -- Bwc#
        Bwd_n       : out STD_LOGIC;                                   -- BWd#
        Rw_n        : out STD_LOGIC;                                   -- RW#
        Oe_n        : out STD_LOGIC;                                   -- OE#
        Ce_n        : out STD_LOGIC;                                   -- CE#
        Ce2_n       : out STD_LOGIC;                                   -- CE2#
        Ce2         : out STD_LOGIC;                                   -- CE2
        Zz          : out STD_LOGIC                                    -- Snooze Mode
    );
end SDRAM_ctrl;

    


architecture Behavioral of SDRAM_ctrl is
    component IOBUF_F_16
      port(
        O  : out   std_logic;
        IO : inout std_logic;
        I  : in    std_logic;
        T  : in    std_logic
        );
    end component; 
    signal Data_out_s : STD_LOGIC_VECTOR (35 downto 0);
    signal Data_in_s : STD_LOGIC_VECTOR (35 downto 0);
    signal Dq_s : STD_LOGIC_VECTOR (35 downto 0);
    signal T_s : STD_LOGIC;
    type StateType is(INIT, IDLE, READ, WRITE);
    signal state : StateType;
    
    -------------------------------------------------------------------
    -- Instanciation de l'IOBUF
    -------------------------------------------------------------------
    
begin
    IOb: for I in 0 to 35 generate
    Iobx: IOBUF_F_16  port map(
        O => Data_out_s(I),
        IO => Dq_s(I),  
        I => Data_in_s(I), 
		T => T_s
        );
    end generate;

    

    -------------------------------------------------------------------
    -- Exemple simple : stockage des donn�es utilisateur
    -------------------------------------------------------------------
    process(clk)
    begin
        if rising_edge(clk) then
            Data_in_s <= "0000" & usr_data_in;
            usr_data_out <= Data_out_s(31 downto 0);
            addr <= usr_addr;
        end if;
    end process;

    -------------------------------------------------------------------
    -- FSM principal
    -------------------------------------------------------------------
    process(clk)
    variable prev_ctrl_RW : std_logic := '0';
    begin
    if rising_edge(clk) then
        -- D�tection des fronts
        if (prev_ctrl_RW = '0' and ctrl_RW = '1') then
            -- Front montant ? d�marrage d'une op�ration
            if RW = '0' then
                state <= WRITE;
            else
                state <= READ;
            end if;

        elsif (prev_ctrl_RW = '1' and ctrl_RW = '0') then
            -- Front descendant ? retour � l'�tat IDLE
            state <= IDLE;

        else
            -- Aucun changement ? maintien de l'�tat courant
            state <= state;
        end if;

        -- M�morisation de l'�tat pr�c�dent du signal ctrl_RW
        prev_ctrl_RW := ctrl_RW;
    end if;
    end process;

    -------------------------------------------------------------------
    -- Sorties combinatoires selon l'�tat
    -------------------------------------------------------------------
    process(state)
    begin
        nCKE   <= '0';
        --nRW    <= '1';
        Lbo_n  <= '0';
        Cke_n  <= '0';
        Ld_n   <= '0';
        Bwa_n  <= '0';
        Bwb_n  <= '0';
        Bwc_n  <= '0';
        Bwd_n  <= '0';
        Rw_n   <= '1';
        Oe_n   <= '0';
        Ce_n   <= '0';
        Ce2_n  <= '0';
        Ce2    <= '1';
        Zz     <= '0';
        Trig   <= '0';
        case state is
            when INIT =>

            when IDLE =>
                

            when READ =>
                Trig <= '1';
                --nRW <='1';

            when WRITE =>
                Trig <= '0';
                --nRW <='0';
        end case;
    end process;

end Behavioral;
